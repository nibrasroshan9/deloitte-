package com;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	Customer customer = new Customer();
        customer.setCustomerName("Abhishek");
    }
}
